# Changes from the supplied F1 and F2 scripts

The supplied F1 and F2 scripts are the computational basis of this package. The goal of this package version is not to redesign them, but to remove the user-supplied/manual threshold branch and connect the existing automatic workflow to one package configuration.

## F1

Retained from the supplied F1:
- RF tuning and OOB evaluation
- SHAP ranking
- k=4..9 feature-set evaluation and Pareto/Entropy-Utopia selection
- after-OFS direction screening
- multiple PDP crossing handling
- 100 bootstrap PDP fits
- fixed-step PV rescue (`0.05`) toward the Sh-yield mean
- two-sided outer-direction density screening
- STi selection
- automatic STa candidate search and Pareto + Linear 4:2:3 selection
- fold-specific LOYO threshold derivation
- negative-OOB-R2 retention/diagnostics
- automatic PDP/density figures

Removed/replaced:
- `FEATURE_STA_RULES`
- parsing of user-supplied feature/STa rules
- original/manual STa benchmark columns
- manual-vs-automatic threshold comparison workbook
- manual density row/figure
- restoration of a manual signature before FULL_DATA

Replacement:
- the existing automatic FULL_DATA RF -> SHAP -> Pareto/Utopia -> PDP direction workflow always defines the fixed feature-direction signature
- that same automatic signature is used by both LOYO and FULL_DATA

## F2

Retained from the supplied F2:
- three-state handling of partial two-sided rules
- fixed signature denominator
- strict-majority rule (>50%)
- `MIN_VALID_FEATURES` only as an evaluability check
- fold-specific STi evaluation
- fold-specific automatic STa evaluation
- TFY/exact-half diagnostics
- OOB-R2 sensitivity
- feature diagnostics
- confusion matrices
- complete alignment workbook structure, including per-year tables, alignment summary, class accuracy, Sh metrics, classification report, dominant stress types, and STa summary

Removed/replaced:
- `FEATURE_STA_RULES`
- manual-rule parser and `MANUAL_RULES`
- original-manual-STa predictions/votes/confusion matrix

Replacement:
- F2 reads feature identities and expected directions from F1's `automatic_full_data_signature.xlsx`
- the former non-independent manual diagnostic is replaced by the FULL-DATA automatic STa diagnostic
- the complete alignment workbook uses FULL-DATA automatic STa thresholds

## Package-only changes

- case name, data path, and `RUN_MODE` are read from `config.py`
- output folders use functional stage names instead of using LOYO as the project name
- `run_pipeline.py` executes the stages in order


## Output/workbook correction
- Fixed an indentation/control-flow bug that made the complete F2 alignment workbook depend on `RUN_LOYO`.
- The workbook is now produced for `FULL_DATA` and `BOTH`, using the full-data automatic STa diagnostic.
- The workbook retains the original 11-sheet F2 layout.
- Generated full-data preprocessing files are now stored inside the case `results` tree instead of beside the input workbook.
